export const apiKey = "b0562214ab9dda5498cef44a98118045";

export const questionInfo = {
  1: "능력발휘",
  2: "자율성",
  3: "보수",
  4: "안정성",
  5: "사회적 인정",
  6: "사회봉사",
  7: "자기계발",
  8: "창의성"
}

export const jobInfo = {
  1 : "중졸이하",
  2 : "고졸",
  3 : "전문대졸",
  4 : "대졸",
  5 : "대학원졸"
}

export const majorInfo = {
  1 : '인문',
  2 : '사회',
  3 : '교육',
  4 : '공학',
  5 : '자연',
  6 : '의학',
  7 : "예체능"
}